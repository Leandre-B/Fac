// Constructeur Formation
function Formation() { }

// Q1 
Formation.prototype._parcours=[];


// Q2
function Parcours(nom, niveau) {
    this.nom = nom;
    this.niveau = niveau;
    this._parcours.push(this);
}

// Héritage
Parcours.prototype = Object.create(Formation.prototype);
Parcours.prototype.constructor = Parcours;

// Q3 

Formation.prototype.nombreParcours = function(){
    let i=0;
    for(let p of this._parcours){
        if(p.niveau==this.niveau)
            i++;
    }
    return i;
}

// DONNEES DE TESTS
const L3I = new Parcours("L3-I", 3);
const LPI = new Parcours("LP-I", 3);
const M1I = new Parcours("M1-I", 4);
const M2CD = new Parcours("M2-CD", 5);
const M2IA = new Parcours("M2-IA", 5);

// A DECOMMENTER POUR REPONDRE A Q3
console.log(M1I.nombreParcours()); // 1
console.log(M2CD.nombreParcours()); // 2