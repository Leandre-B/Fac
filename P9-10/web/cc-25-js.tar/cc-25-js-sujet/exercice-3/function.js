let pokemonCount = 2;

// Q1
let remplirNatures = function() {
    const natures = ["Rigide", "Timide", "Modeste", "Jovial", "Assuré"];

    let div = document.createElement("div");

    let labelNature = document.createElement("label");
    labelNature.textContent = "Nature";
    div.append(labelNature);

    let select = document.createElement("select");

    let def = document.createElement("option");
    def.value = "";
    def.innerText = "--Choisir--";
    def.disabled = true;
    def.selected = true;

    select.append(def);

    for(let n of natures){
        let opt = document.createElement("option");
        opt.value = n;
        opt.innerText = n;
        select.append(opt);

    }
    div.append(select);

    document.querySelectorAll("div")[1].insertBefore(div, document.querySelectorAll("div")[1].lastChild);

}();


// Q2
function changeColor() {

    let div_type = (document.querySelectorAll("div")[3].children);
    let section = document.querySelectorAll("div")[3].parentNode.parentNode

    for(let i =1; i<=3; i++){
        if(div_type[1][i].selected){
            if(div_type[1][i].value==="feu")
                section.classList = "type-feu";
            if(div_type[1][i].value==="eau")
                section.classList = "type-eau";
            if(div_type[1][i].value==="plante")
                section.classList = "type-plante";
        }
    }

}


// Q3
function recupererDonnees() {
//     La saisie est invalide si l’un des champs texte est vide ou si l’option par défaut a été conservée pour l’un des
// menus.
// • L’objet à renvoyer a 4 propriétés dénommées “nom”, “espèce”, “nature” et “type” qui prennent pour
// valeurs ce qu’à saisi le visiteur et les valeurs des options qu’il a choisies.

    let obj = {
        nom :"",
        espece :"",
        nature :"",
        type :"",
    };

    let textes = document.querySelectorAll("input[type=\"text\"]");
    let i=0;
    for(let t of textes){
        if(t.value=="")
            return null;
        if(i==0)
            obj.nom=t.value;
        if(i==1)
            obj.espece=t.value;
        i++;
    }

    let div_type = (document.querySelectorAll("div")[3].children);

    if(div_type[1][0].selected)
        return null;

    for(let i =1; i<=3; i++){
        if(div_type[1][i].selected){
            if(div_type[1][i].selected)
                obj.type=div_type[1][i].value;
        }
    }

    let div_nature = (document.querySelectorAll("div")[2].children);
    if(div_nature[1][0].selected)
        return null;

    for(let i =1; i<=5; i++){
        if(div_nature[1][i].selected){
            if(div_nature[1][i].selected)
                obj.nature=div_nature[1][i].value;
        }
    }


    // On retourne un objet 
    return obj;
}


// Q4
function insererDansTableau(pkm) {
    //'<button onclick="deletePokemon(this)">&#10006;</button>';

    let ligne_vide = document.querySelector("tr[data-empty=\"true\"]");
    if(ligne_vide != null){
        ligne_vide.removeAttribute("data-empty");
        console.log(ligne_vide.children);
        ligne_vide.children[1].innerHTML = "<strong>" + pkm.espece + "</strong> (" + pkm.nom + ")</td>";
        ligne_vide.children[2].innerHTML = "<span style=\"background-color: var(--" + pkm.type + ");\">"+pkm.type+"</span></td>";
        ligne_vide.children[3].innerHTML = "<button onclick=\"deletePokemon(this)\">&#10006;</button>"; 
    }


    return false;
}


//=====================
//Main
function addPokemon() {
    if (pokemonCount >= 3) return;

    // Récupération
    const pkm = recupererDonnees();

    // Test
    if (pkm) {
        // Insertion
        if (insererDansTableau(pkm)) {
            pokemonCount++;
            updateUI();
        }
    }
}

function updateUI() {
    // Cible le span dans le h2 de la seconde section
    document.querySelector('section:last-of-type h2 span').innerText = pokemonCount;

    const btn = document.querySelector('form button');
    btn.disabled = (pokemonCount >= 3);
    btn.style.opacity = (pokemonCount >= 3) ? "0.5" : "1";
}