
function deletePokemon(btn) {
    const row = btn.closest('tr');
    if (row.getAttribute('data-empty') === 'true') return;

    row.setAttribute('data-empty', 'true');
    row.cells[1].innerText = "---"; // Nom et Espèce
    row.cells[2].innerText = "---"; // Type
    row.cells[3].innerHTML = "";    // On enlève le bouton lui-même

    pokemonCount--;
    updateUI();
}
