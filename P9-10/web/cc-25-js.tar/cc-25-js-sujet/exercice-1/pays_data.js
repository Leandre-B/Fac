const pays_oceanie = [
  {
    nom: "Australie",
    nb_habitants: 25890773,
    superficie: 7688287,
    drapeau: {
      couleurs: ["bleu", "rouge", "blanc"],
      ratio: 2.0,
      annee_adoption: 1903
    }
  },
  {
    nom: "Nouvelle Zélande",
    nb_habitants: 4993923,
    superficie: 263310,
    drapeau: {
      couleurs: ["bleu", "rouge", "blanc"],
      ratio: 2.0,
      annee_adoption: 1902
    }
  },
  {
    nom: "Papouasie Nouvelle Guinée",
    nb_habitants: 10185363,
    superficie: 462840,
    drapeau: {
      couleurs: ["rouge", "noir", "jaune"],
      ratio: 4 / 3,
      annee_adoption: 1971
    }
  },
  {
    nom: "Fidji",
    nb_habitants: 926276,
    superficie: 18274,
    drapeau: {
      couleurs: ["bleu", "blanc", "rouge"],
      ratio: 2.0,
      annee_adoption: 1970
    }
  },
  {
    nom: "Îles Salomon",
    nb_habitants: 721956,
    superficie: 28896,
    drapeau: {
      couleurs: ["bleu", "vert", "jaune", "blanc"],
      ratio: 2.0,
      annee_adoption: 1977
    }
  },
  {
    nom: "Vanuatu",
    nb_habitants: 300019,
    superficie: 12189,
    drapeau: {
      couleurs: ["rouge", "vert", "noir", "jaune"],
      ratio: 36 / 19,
      annee_adoption: 1980
    }
  },
  {
    nom: "Samoa",
    nb_habitants: 205557,
    superficie: 2831,
    drapeau: {
      couleurs: ["rouge", "bleu", "blanc"],
      ratio: 2.0,
      annee_adoption: 1949
    }
  },
  {
    nom: "Kiribati",
    nb_habitants: 119438,
    superficie: 811,
    drapeau: {
      couleurs: ["rouge", "bleu", "blanc", "jaune"],
      ratio: 2.0,
      annee_adoption: 1979
    }
  },
  {
    nom: "Tonga",
    nb_habitants: 103197,
    superficie: 747,
    drapeau: {
      couleurs: ["rouge", "blanc"],
      ratio: 2.0,
      annee_adoption: 1875
    }
  },
  {
    nom: "États fédérés de Micronésie",
    nb_habitants: 75817,
    superficie: 702,
    drapeau: {
      couleurs: ["bleu", "blanc"],
      ratio: 19 / 10,
      annee_adoption: 1978
    }
  },
  {
    nom: "Palaos",
    nb_habitants: 16766,
    superficie: 459,
    drapeau: {
      couleurs: ["bleu", "jaune"],
      ratio: 8 / 5,
      annee_adoption: 1981
    }
  },
  {
    nom: "Îles Marshall",
    nb_habitants: 42418,
    superficie: 181,
    drapeau: {
      couleurs: ["bleu", "orange", "blanc"],
      ratio: 19 / 10,
      annee_adoption: 1979
    }
  },
  {
    nom: "Nauru",
    nb_habitants: 12025,
    superficie: 21,
    drapeau: {
      couleurs: ["bleu", "jaune", "blanc"],
      ratio: 2.0,
      annee_adoption: 1968
    }
  },
  {
    nom: "Tuvalu",
    nb_habitants: 10643,
    superficie: 26,
    drapeau: {
      couleurs: ["bleu", "rouge", "blanc", "jaune"],
      ratio: 2.0,
      annee_adoption: 1978
    }
  }
];
