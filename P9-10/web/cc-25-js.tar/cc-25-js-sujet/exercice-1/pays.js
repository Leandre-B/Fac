// Q1
let pays_dens = [];


for(let p of pays_oceanie){
    let obj = new Object;
    obj.nom = p.nom;
    obj.drapeau = p.drapeau;
    obj.densite = (p.nb_habitants/p.superficie);
    pays_dens.push(obj);
}

// Q2
let pays_rouge = 0;

for(let p of pays_oceanie){
    if(p.drapeau.couleurs.includes("rouge"))
        pays_rouge++;
}

// Q3

let pays_siecle = new Object;
for(let p of pays_oceanie){
    if(pays_siecle.hasOwnProperty(p.drapeau.annee_adoption))
        pays_siecle[p.drapeau.annee_adoption]++;
    else{
        pays_siecle[p.drapeau.annee_adoption]=1;
    }
}

// Q4
let pays_couleurs = [];
let pays_couleurs_aux = []; // [[nom, couleur.lenght], ...]
for(let p of pays_oceanie){
    pays_couleurs_aux.push([p.nom, p.drapeau.couleurs.length]);
}

pays_couleurs_aux.sort((a, b) => b[1] - a[1]);
for(let p of pays_couleurs_aux){
    pays_couleurs.push(p[0])
}
console.log(pays_couleurs_aux);


// Q5
let pays_court = [];

for(let p of pays_oceanie){
    if(p.nom.slice(" ").length>0 && p.nom.length>12){
        let abr = "";
        for(m of p.nom.split(" ")){
            abr+=m[0];
        }
        pays_court.push(abr);
    }
    else
        pays_court.push(p.nom);
}
